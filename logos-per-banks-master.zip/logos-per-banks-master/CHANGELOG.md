# Changelog

## [1.1.0] - 2018-08-01
### Added
- CHANGELOG.md
- Hesabit Logo-Color & Mono
- [Hesabit.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Gateway/Color/Hesabit.svg) in SVG Assets/Gateways/Color
- [Hesabit.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Gateway/Mono/Hesabit.svg) in SVG Assets/Gateways/Mono

### Changed
- "SVG Exports" to "SVG Assets"

- Sedad to Sadad in all files

- Iran Zamin Logo - Color : Updated the colors based on website hex codes
- [Iran_Zamin.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Bank/Color/Iran_Zamin.svg) in SVG Assets/Bank/Color
- [Iran_Zamin.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Bank/Mono/Iran_Zamin.svg) in SVG Assets/Bank/Mono

- Kosar Logo - Color & Mono: Updated the whole shape based on new logo
- [Kosar.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Bank/Color/Kosar.svg) in SVG Assets/Bank/Color
- [Kosar.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Bank/Mono/Kosar.svg) in SVG Assets/Bank/Mono

- Maskan Logo - Color & Mono: Enhanced the whole shape
- [Maskan.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Bank/Color/Maskan.svg) in SVG Assets/Bank/Color
- [Maskan.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Bank/Color/Maskan.svg) in SVG Assets/Bank/Color

- Payping Logo - Color & Mono: Updated the whole shape based on new logo
- [Payping.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Gateway/Color/Payping.svg) in SVG Assets/Gateways/Color
- [Payping.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Gateway/Mono/Payping.svg) in SVG Assets/Gateways/Mono

- Sedad.svg to [Sadad.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Gateway/Color/Sadad.svg) in SVG Assets/Gateways/Color
- [Sadad.svg](https://github.com/zegond/logos-per-banks/blob/master/SVG%20Assets/Gateway/Mono/Sadad.svg) in SVG Assets/Gateways/Mono